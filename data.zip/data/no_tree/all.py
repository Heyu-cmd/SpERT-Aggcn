import json
import os
path = "/Users/heyup/PycharmProjects/Knowledge_Graph/data/datasets/data/no_tree"
dirs = os.listdir(path)
all = []
print(dirs)
for dir in dirs:
    if "data" not in dir:
        continue
    f = open(dir, 'r',encoding="utf8")
    datas = json.load(f)
    all.extend(datas)

with open("./all.json", "w", encoding="utf8") as f:
    json.dump(all, f, ensure_ascii=False)